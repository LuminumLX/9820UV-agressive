#!/system/bin/sh
#   9820UV (Undervolt Only) for Exynos 9820 by LuminumLX
#   Undervolt Little, Mid & Big cores to reduce power consumption and increase clocks & performance per watt
#   Agressive Big cluster undervolt & lighter UV on mid & little due to Exynos M4 cluster inefficiency
sleep 5
# undervolt at sys power percent margin
echo '-7' > /sys/power/percent_margin/big_margin_percent
echo '-4' > /sys/power/percent_margin/mid_margin_percent
echo '-4' > /sys/power/percent_margin/lit_margin_percent
echo '-5' > /sys/power/percent_margin/score_margin_percent
echo '-5' > /sys/power/percent_margin/iva_margin_percent
echo '-5' > /sys/power/percent_margin/fsys0_margin_percent
echo '-5' > /sys/power/percent_margin/mif_margin_percent
echo '-5' > /sys/power/percent_margin/npu_margin_percent
echo '-10' > /sys/power/percent_margin/g3d_margin_percent
echo '-5' > /sys/power/percent_margin/mfc_margin_percent
