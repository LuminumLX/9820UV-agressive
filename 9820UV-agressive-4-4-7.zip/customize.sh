#!/system/bin/sh
ui_print "Installing 9820UV 4-4-7..."
ui_print "Tip - if crashes occur, disable the module or flash the less agressive version"
ui_print "Installation complete!"